# RGISpy
Python wrapper for the RGIS (River GIS) framework and data structure

The rgis folder contains the code that implements the wrapper classes

The two other files are test files
